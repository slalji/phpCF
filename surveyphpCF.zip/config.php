<?php
    //set off all error for security purposes
	error_reporting(E_ALL);
	

	//define some contstant
    define( "DB_DSN", "mysql:host=localhost;dbname=likejagg_dtcu" );
    define( "DB_USERNAME", "likejagg_dtcu" );
    define( "DB_PASSWORD", "vHL_bM%ry4ND" );
	define( "CLS_PATH", "class" );
	
	
?>

<link rel='stylesheet" type="text/css" href="style.css' />
<center><h1>
You have completed the survey, thank you for participating.</h1>
   
  
    
   
</center>